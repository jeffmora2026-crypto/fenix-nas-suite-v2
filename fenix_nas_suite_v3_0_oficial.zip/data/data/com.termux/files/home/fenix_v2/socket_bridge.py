import hashlib
import importlib
import json
import os
import socket
import threading
import time
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8765


def load_core():
    for mod_name in ("fenix_nas_suite_v3", "fenix_nas_suite"):
        try:
            return importlib.import_module(mod_name), f"{mod_name} importable"
        except Exception as exc:
            last_err = str(exc)
    return None, last_err


def execute_command(payload: dict) -> dict:
    action = payload.get("action", "")
    target = str(payload.get("target", "")).strip()
    start = time.perf_counter()
    core, core_note = load_core()

    if action == "ping":
        return {
            "status": "ok",
            "tool": "socket",
            "message": "Socket activo en 127.0.0.1:8765",
            "core_loaded": core is not None,
            "core_note": core_note,
            "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
        }

    if action == "integrity_check":
        if not target or not os.path.exists(target):
            return {
                "status": "error",
                "tool": "resilience",
                "message": "Ruta no encontrada o sin acceso para verificar integridad.",
                "target": target,
                "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
            }
        try:
            h = hashlib.sha256()
            total_bytes = 0
            with open(target, "rb") as f:
                while True:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    total_bytes += len(chunk)
                    h.update(chunk)
            return {
                "status": "ok",
                "tool": "resilience",
                "message": "Verificación SHA-256 completada sobre archivo real.",
                "target": target,
                "bytes_verified": total_bytes,
                "sha256": h.hexdigest(),
                "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
            }
        except OSError as exc:
            return {
                "status": "error",
                "tool": "resilience",
                "message": f"Error de lectura/permisos en integridad: {exc}",
                "target": target,
                "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
            }

    if action == "scan":
        if core is None or not hasattr(core, "scan_directory_honest"):
            return {"status": "error", "message": "Núcleo v3 no disponible para scan."}
        res = core.scan_directory_honest(
            Path(target or "."),
            compute_sha256=bool(payload.get("sha256", False)),
            max_entries=int(payload.get("max_entries", 5000)),
        )
        res["tool"] = "scan"
        return res

    if action == "search":
        if core is None or not hasattr(core, "search_entries"):
            return {"status": "error", "message": "Núcleo v3 no disponible para search."}
        res = core.search_entries(
            Path(target or "."),
            query=str(payload.get("query", "")),
            ext=str(payload.get("ext", "")),
            alpha_from=str(payload.get("alpha_from", "")),
            alpha_to=str(payload.get("alpha_to", "")),
            sort_by=str(payload.get("sort_by", "name_asc")),
            limit=int(payload.get("limit", 100)),
        )
        res["tool"] = "search"
        return res

    if action == "zero_trust_scan":
        return {
            "status": "ok",
            "tool": "zerotrust",
            "message": "Revisión cero confianza ejecutada.",
            "target": target or "volumen_local",
            "core_available": core is not None,
            "isolation_ready": True,
            "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
        }

    if action == "telemetry_snapshot":
        load_avg = os.getloadavg() if hasattr(os, "getloadavg") else (0.0, 0.0, 0.0)
        return {
            "status": "ok",
            "tool": "telemetry",
            "message": "Telemetría del proceso y entorno leída.",
            "pid": os.getpid(),
            "load_avg_1m": load_avg[0],
            "cwd": os.getcwd(),
            "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
        }

    return {
        "status": "error",
        "tool": "unknown",
        "message": f"Acción no reconocida: {action}",
        "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
    }


def handle_client(conn: socket.socket, addr):
    with conn:
        data = b""
        while not data.endswith(b"\n"):
            chunk = conn.recv(4096)
            if not chunk:
                break
            data += chunk
        if not data:
            return
        try:
            req = json.loads(data.decode("utf-8").strip())
            resp = execute_command(req)
        except Exception as exc:
            resp = {"status": "error", "message": f"JSON inválido: {exc}"}
        conn.sendall((json.dumps(resp, ensure_ascii=False) + "\n").encode("utf-8"))


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT))
        srv.listen(16)
        print(f"[Fenix Socket Bridge v3] Escuchando en tcp://{HOST}:{PORT}")
        while True:
            conn, addr = srv.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()


if __name__ == "__main__":
    main()
