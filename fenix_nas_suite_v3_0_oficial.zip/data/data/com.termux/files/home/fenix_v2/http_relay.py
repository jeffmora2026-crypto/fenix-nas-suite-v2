import json
import os
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HTTP_HOST = "127.0.0.1"
HTTP_PORT = 8766
TCP_HOST = "127.0.0.1"
TCP_PORT = 8765
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(BASE_DIR, "ui", "dashboard.html")


def forward_to_socket(payload_bytes: bytes) -> bytes:
    line = payload_bytes.strip() + b"\n"
    with socket.create_connection((TCP_HOST, TCP_PORT), timeout=10) as s:
        s.sendall(line)
        chunks = []
        while True:
            data = s.recv(8192)
            if not data:
                break
            chunks.append(data)
            if b"\n" in data:
                break
        return b"".join(chunks).strip()


class RelayHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_json(self, code: int, body_bytes: bytes):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.end_headers()
        self.wfile.write(body_bytes)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html", "/dashboard.html"):
            if not os.path.exists(UI_FILE):
                self._send_json(404, b'{"status":"error","message":"Falta ui/dashboard.html"}')
                return
            with open(UI_FILE, "rb") as f:
                html = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        else:
            self._send_json(404, b'{"status":"error","message":"Ruta no encontrada"}')

    def do_POST(self):
        if self.path != "/cmd":
            self._send_json(404, b'{"status":"error","message":"Endpoint no encontrado"}')
            return
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        try:
            json.loads(raw.decode("utf-8"))
            reply = forward_to_socket(raw)
            self._send_json(200, reply)
        except Exception as exc:
            err = json.dumps({"status": "error", "message": f"Fallo en relay: {exc}"}).encode("utf-8")
            self._send_json(502, err)


def main():
    srv = ThreadingHTTPServer((HTTP_HOST, HTTP_PORT), RelayHandler)
    print(f"[Fenix HTTP Relay] http://{HTTP_HOST}:{HTTP_PORT} -> tcp://{TCP_HOST}:{TCP_PORT}")
    srv.serve_forever()


if __name__ == "__main__":
    main()
